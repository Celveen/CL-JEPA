# 视觉偏移模型（PushObj-T-16k）训练超参数：补训练种子 1、2

目标：用和 seed 0 完全相同的设置，只把训练种子换成 1 和 2，各训练 3 轮，用来估计训练随机性对结果的影响。

## 1. 准备

1. **代码**：官方仓库 https://github.com/agentic-learning-ai-lab/adajepa ，切到提交 `51d8665`，再应用我们的改动：
   ```bash
   git clone https://github.com/agentic-learning-ai-lab/adajepa.git && cd adajepa && git checkout 51d8665
   git apply /path/to/train_hparams_pushobj_T16k/code/code_changes.patch
   ```
   也可以不打补丁，直接用 `code/` 下的 6 个文件覆盖仓库里的同名文件。改动内容：多卡训练时读取编码器属性的修复（不改多卡会报错）、
   数据打乱用由训练种子固定的生成器、只解码用到的视频帧（提速）、曲率损失在全静止窗口时返回 0 而不是 NaN、日志与断点续训。损失和优化器与原代码相同。
2. **环境**：`env/environment.yaml`（conda 环境 ts，Python 3.9），需要 accelerate。
3. **数据**：把 pushobj_T16k_bias_data.zip 里的 `train/` 和 `val/` 放到仓库的 `data/pushobj_T16k_bias/` 下
   （16,000 条训练 + 1,000 条验证）。配置里的路径是 `${hydra:runtime.cwd}/data/pushobj_T16k_bias`，所以要在仓库根目录启动。
4. **配置**：把 `conf/train_pushobj_T16k_seed1.yaml`、`conf/train_pushobj_T16k_seed2.yaml` 拷到仓库的 `conf/`。
   `conf/` 下其余文件是它们组合用到的基础配置，与 51d8665 的原文件相同，只作对照。

## 2. 训练命令（在仓库根目录）

4 张卡（我们用 4 张 RTX 3090，每卡 batch 16，bf16，每轮约 54 分钟，3 轮约 2.7 小时）：
```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 WANDB_MODE=offline SDL_VIDEODRIVER=dummy accelerate launch --multi_gpu --num_processes 4 --mixed_precision bf16 train.py --config-name train_pushobj_T16k_seed1
CUDA_VISIBLE_DEVICES=0,1,2,3 WANDB_MODE=offline SDL_VIDEODRIVER=dummy accelerate launch --multi_gpu --num_processes 4 --mixed_precision bf16 train.py --config-name train_pushobj_T16k_seed2
```
或者 `bash run_train_seeds.sh 0,1,2,3`，依次训练两个种子。卡数可以不同：`training.batch_size: 64` 是总 batch，代码按卡数平分，
**卡数必须能整除 64**（1、2、4、8），不要改 batch_size。单卡时去掉 `--multi_gpu` 并设 `--num_processes 1`。

输出目录：`checkpoints/pushobj_T16k_bias_e3_seed1/`、`..._seed2/`，里面有 `hydra.yaml`、`checkpoints/model_1..3.pth`、`model_latest.pth`、
`metrics.jsonl`（每轮验证损失）、`metrics_iter.jsonl`、`train.log`。

## 3. 关键超参数（完整值见 reference/resolved_config_seed0.yaml）

| 项目 | 值 |
|---|---|
| 训练轮数 | 3 |
| 总 batch | 64（4 卡时每卡 16） |
| encoder / predictor / action / proprio encoder lr | 1e-5 / 5e-4 / 5e-4 / 5e-4 |
| 历史帧 / 预测帧 / frameskip | 3 / 1 / 5 |
| 曲率正则 straighten | cos1e-2 |
| stop-grad | 是 |
| decoder | 不训练（has_decoder: false） |
| 编码器 / 预测器 | SmallResNetGeM（dim 384，GeM p=3）/ ViT 6 层 16 头，mlp 2048，dropout 0.1 |
| 混合精度 | bf16 |
| 训练种子 | seed 0（已完成）、**seed 1、seed 2（待训练）** |

## 4. seed 0 的参考曲线（新种子应落在附近）

| 轮 | 训练潜在 MSE | 验证潜在 MSE | 验证 1−cos | 分钟 |
|---|---|---|---|---|
| 1 | 0.0367 | 0.0180 | 0.601 | 53 |
| 2 | 0.0144 | 0.0132 | 0.540 | 54 |
| 3 | 0.0104 | 0.0107 | 0.508 | 54 |

完整记录在 `reference/metrics_seed0.jsonl` 和 `reference/metrics_iter_seed0.jsonl`。不同种子的验证潜在 MSE 一般只差几个百分点；
如果差到成倍，先检查数据路径和代码版本。即使种子相同，多卡 bf16 训练也不会逐位相同。

## 5. 训练完后发回

每个种子的输出目录里的：`hydra.yaml`、`checkpoints/model_3.pth`（或 `model_latest.pth`，两者权重相同）、`metrics.jsonl`、`metrics_iter.jsonl`、`train.log`。
`checkpoints/model_e*_it*.pth` 是每 5000 次迭代存的中间检查点，可以不发。
