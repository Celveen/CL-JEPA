#!/bin/bash
# Train the visual-shift model with training seeds 1 and 2, one after the other.
# Usage (from the repository root): bash run_train_seeds.sh 0,1,2,3   # GPU ids; their count must divide 64
set -e
GPUS=${1:-0,1,2,3}
N=$(echo "$GPUS" | tr ',' '\n' | wc -l)
MULTI=""; [ "$N" -gt 1 ] && MULTI="--multi_gpu"
for S in 1 2; do
  CUDA_VISIBLE_DEVICES=$GPUS WANDB_MODE=offline SDL_VIDEODRIVER=dummy OMP_NUM_THREADS=4 \
    accelerate launch $MULTI --num_processes "$N" --mixed_precision bf16 --main_process_port $((29500 + S)) \
    train.py --config-name train_pushobj_T16k_seed$S 2>&1 | tee train_seed$S.console.log
done
